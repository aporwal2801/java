package com.practise.jms.JMSSpringBootApplication.exception;



public class OrderException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	

	public OrderException(String value) {
	
	super(value);
	System.out.println("Exception occured" +" "+value);
	}
	
	
}
