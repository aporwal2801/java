package com.practise.jms.JMSSpringBootApplication.producer;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

import com.practise.jms.JMSSpringBootApplication.exception.OrderException;
import com.practise.jms.JMSSpringBootApplication.item.Order;

@Service
public class OrderProducer implements IOrderProducer{

	@Autowired
	private JmsTemplate jmstemplate;
	
	@Value("${jms.orderqueue.destination}")
	private String destinationQueue;
	
	@Override
	public void sendOrder(@Valid Order item) throws OrderException{
		if(null!= item && (item.getPrice()>0)){
		System.out.println("Sending Order............");
		Object message = item;
		jmstemplate.convertAndSend(destinationQueue, message);
		}
		
		else
		throw new OrderException("Exception in sending Order");
	}

	
}
