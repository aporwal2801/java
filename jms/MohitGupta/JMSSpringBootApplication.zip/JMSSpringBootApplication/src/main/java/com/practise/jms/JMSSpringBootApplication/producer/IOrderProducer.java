package com.practise.jms.JMSSpringBootApplication.producer;

import com.practise.jms.JMSSpringBootApplication.exception.OrderException;
import com.practise.jms.JMSSpringBootApplication.item.Order;

public interface IOrderProducer {

	void sendOrder(Order message) throws OrderException;
}
