package com.practise.jms.JMSSpringBootApplication;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.practise.jms.JMSSpringBootApplication.consumer.IorderConsumerProducer;
import com.practise.jms.JMSSpringBootApplication.exception.OrderException;
import com.practise.jms.JMSSpringBootApplication.item.Order;
import com.practise.jms.JMSSpringBootApplication.producer.IOrderProducer;

@RestController
@RequestMapping("jms")
public class OrderService {

	@Autowired
	private IOrderProducer producer;
	@Autowired
	private IorderConsumerProducer producerconsumer;

	@RequestMapping(value = "orderService/send", method = RequestMethod.POST)
	public void sendOrderToOrderQueue(@RequestBody Order order) {

		System.out.println("price" + order.getPrice() + " " + "quantity"
				+ order.getQuantity());

		try {
			producer.sendOrder(order);
		} catch (OrderException e) {
			System.out.println("order exception");
		}

	}

	@RequestMapping(value = "orderService/receive", method = RequestMethod.GET)
	public String processOrder() throws OrderException {

		String response = null;
		try {
			Order order = producerconsumer.recieve();
			System.out.println("Consumed=" + order.toString());
			if (order.isProcessed()) {
				response = sendTOExportQueue(order);
				System.out.println("exported -->" + response);
			}
		} catch (OrderException e) {

			throw new OrderException("Order not processed!");
		}
		return response;
	}

	public String sendTOExportQueue(Order order) {

		Order exportOrder = producerconsumer.execute(order);

		return exportOrder.toString();
	}
}
