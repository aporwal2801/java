package com.practise.jms.JMSSpringBootApplication.item;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import org.springframework.stereotype.Component;

@Component
public class Order implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 99991L;

	public long getPrice() {
		return price;
	}


	

	public long getQuantity() {
		return quantity;
	}

	private long orderId;
	
	public long getOrderId() {
		return orderId;
	}

	@NotNull
	private long price;
	
	
	
	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}




	public void setPrice(long price) {
		this.price = price;
	}




	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}

	private long quantity;
	
	
	private boolean processed;

	public boolean isProcessed() {
		return processed;
	}

	public void setProcessed(boolean processed) {
		this.processed = processed;
	}
	
	public Order() {
		
	}
	
	@Override
	public String toString() {
		
		return " Order Id: "+ getOrderId() + " " + " Price: " + getPrice() + " " + " Quantity: " +  
				+ getQuantity() + " " + " Processed:" + isProcessed();
	}
	
}
