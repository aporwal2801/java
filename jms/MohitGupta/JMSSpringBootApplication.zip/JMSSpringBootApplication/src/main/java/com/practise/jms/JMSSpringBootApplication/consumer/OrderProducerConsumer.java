package com.practise.jms.JMSSpringBootApplication.consumer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

import com.practise.jms.JMSSpringBootApplication.exception.OrderException;
import com.practise.jms.JMSSpringBootApplication.item.Order;

@Service
public class OrderProducerConsumer implements IorderConsumerProducer {

	@Autowired
	private JmsTemplate jmstemplate;

	@Value("${jms.orderqueue.destination}")
	private String destinationQueue;
	
	@Value("${jms.exportedqueue.destination}")
	private String exportedOrderQueue;
	
	private Order order;
	

	@Override
	public Order recieve() throws OrderException {
		order = (Order) jmstemplate.receiveAndConvert(destinationQueue);
		if (order.getQuantity() > 0) {
			order.setProcessed(true);
			return order;

		} 
		
		else
		System.out.println("Order Consumed :" + order.toString());
		throw new OrderException("Quantity Not Available");

	}

	@Override
	public String toString() {
		return order.getOrderId() + " " + order.getPrice() + " "
				+ order.getQuantity() + " " + order.isProcessed();
	}

	@Override
	public Order execute(Order order) {
		System.out.println("Exporting order=>"+order.getOrderId());
		jmstemplate.convertAndSend(exportedOrderQueue, order);
		return order;
		
	}
}
