package com.practise.jms.JMSSpringBootApplication.consumer;

import com.practise.jms.JMSSpringBootApplication.exception.OrderException;
import com.practise.jms.JMSSpringBootApplication.item.Order;

public interface IorderConsumerProducer {

	Order recieve() throws OrderException;
	
	Order execute(Order order);
}
